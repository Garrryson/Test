shell.execute("wget https://raw.githubusercontent.com/IgorTimofeev/OpenComputers/master/lib/ECSAPI.lua lib/ECSAPI.lua -f")
shell.execute("reboot")
