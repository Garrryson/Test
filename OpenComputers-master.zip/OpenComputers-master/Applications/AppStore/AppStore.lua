local ecs = require("ECSAPI")
ecs.universalWindow("auto", "auto", 30, 0xeeeeee, true, {"EmptyLine"}, {"CenterText", 0x262626, "Hello world!"}, {"EmptyLine"}, {"Button", {0x880000, 0xffffff, "Hello!"}})
